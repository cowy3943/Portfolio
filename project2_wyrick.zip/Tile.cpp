#include <iostream>
#include "Tile.h"
#include <cstdlib> // rand()
#include <ctime>
#include "Board.h"
#include "Player.h"
#include "CandyLand.h"

using namespace std;



Tile::Tile()
{
// sets up all tile
Board h;
assignHiddenTreasures(h);

}

void Tile::assignHiddenTreasures(Board h) const
{
    int number = (rand() % (27 - 1 + 1)) + 1;
    h.addHiddenTreasure(number);
    int number1 = (rand() % (54 - 28 + 1)) + 28;
    h.addHiddenTreasure(number1);
    int number2 = (rand() % (82 - 55 + 1)) + 55;
    h.addHiddenTreasure(number2);
}

int Tile::useHiddenTreasures(Player p)
{
// randomely assigns 3 hidden treasures
// impliments riddles at each position


// 1. Open Riddle File
// 2. separate riddle and answer with stringstream
// 3. prompt user for answer after displaying riddle
// 4.  if (riddle passed)

if(true)
{
int num = (rand() % (100 - 1 + 1)) + 1;
if(num >=1 && num <=30)
{
    int num = (rand() % (30 - 10 + 1)) + 10;
    p.setStamina(p.getStamina() + num);
    //stamina refill 10 - 30 units (max 100)
    return 0;
}
if(num >30 && num <=40)
{
    int num1 = (rand() % (40 - 20 + 1)) + 20;
    p.setGold(p.getGold() + num1);
    //gold refill 20 - 40 (max 100)
    return 0;
}
if(num >40 && num <= 70)
{
    //anti-robbery sheild while on same tile
    return 1; // if returned 1, anti robbery sheild in use
}
if(num > 70 && num <=100)
{
    int num1 = (rand() % (100 - 1 + 1)) + 1;
    if (num1 >= 1 && num1 <= 70)
    {
        Candy jellybean_of_vigor;
        p.addCandy(jellybean_of_vigor);
       // player recieves Jellybean of Vigor
       // (restores 50 units of stamina)
       return 0;
    }
    if (num1 >70 && num1 <= 100)
    {
        Candy treasures_hunters_truffle;
        p.addCandy(treasures_hunters_truffle);
      //  player recieves Treasures Hunter's Truffle
      //  (allows player to unlock hidden treasure)
      return 0;
    }
}
}
return 0;
}

int Tile::setSpecialTiles(Board h, Player p) 
{
int number3 = (rand() % (4 - 1 + 1)) + 1;
if (number3 == 1)
{
    int num = (rand() % (100 - 1 + 1)) + 1;
if (num >=1 && num <=25)
    {
        h.setPlayerPosition(h.getPlayerPosition() + 4);
        cout << " Your spirits soar as you're propelled four tiles ahead, closing in on the Candy Castle." << endl;
        return 0;
    }
    if (num >25 && num <=50)
    {
        // Ice Cream Shop
        // if 1 is returned, loop back to main menu
        cout << "Congrats! You get a chance to draw a card again." << endl;
        return 1;

    }
    if (num >50 && num <=75)
    {
        // Gum Drop Forest
        h.setPlayerPosition(h.getPlayerPosition() - 4);
        p.setGold(p.getGold() - 5);
        cout << "Oops, You head back 4 tiles and lose 5 gold." << endl;
        return 0;
    }
    if (num >75 && num <=100)
    {
       // Ginger bread House
       //remove immunity candy
       //1. find immunity candy
       //2. use remove candy function
       //return to previous position
       //1. find previous position
       //2. subtract position on board
        cout << "It's a bittersweet return to your previous location, accompanied by the forfeiture of one immunity candy." << endl;
        return 0;
    }
    return 0;
}
else
{
    return 0;// not a special tile
}
}

int Tile::setMarshmallowHailstorm(Board h, Board p) 
{
    int number4 = (rand() % (20 - 1 + 1)) + 1;
    if (number4 == 1)
    {
        int num1 = (rand() % (5 - 1 + 1)) + 1;
        h.setPlayerPosition(h.getPlayerPosition() - num1);
        p.setPlayerPosition(p.getPlayerPosition() - num1);
        return 1;
    }
    return 0;
}
