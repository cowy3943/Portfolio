// CSCI1300 Fall 2023 Project 2
// Author: Cooper Wyrick
// Recitation TA: Kyler Ruvane
// Date: 12/6/2023

// how to run:
//g++ -std=c++17 -Wall -Werror -Wpedantic Board.cpp gameDriver.cpp CandyLand.cpp CandyStore.cpp Player.cpp Tile.cpp

#include <iostream>
#include <cctype>
#include "CandyLand.h"
#include "Board.h"
#include "Tile.h"
#include "Player.h"
#include "CandyStore.h"
#include <fstream>
#include <sstream>
#include <cstdlib> // rand()
#include <ctime>

using namespace std;

int main()
{

    srand(time(0));
    CandyLand c;
    c.setupGame();
    
    return 0;
}