#include <iostream>
#include <vector>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <sstream>
#include "Player.h"
#include "Board.h"

#ifndef CANDYLAND_H
#define CANDYLAND_H
using namespace std;



struct Card
{
string color;
string type; // double or single

};

class CandyLand
{
    public:
   
    void setupGame(); // set up board, special tiles, candy stores
    vector<Candy> readCandy(string, vector <Candy>);
    void displayCandy(vector <Candy>); // displays each characters stats
    bool samePosition(Board, Board, Player, Player); // what happens when characters have same position
    int ifCalamities(Player); // 40% chance of calamities
    void displayMainMenu(Player, Player);
    Card drawCard ();  // moves player and returns card
    

    private:
    vector <Candy> _candies;

};

// CandyLand::setupGame()
// {
//     loadCandy();
//     startGame();
// }

#endif




/*

struct -> candy, card
class -> Player, Board, Tile, CandyLand, CandyStore

0. set up the game
        set up board -> 83
        place special tiles
        place candy stores
        .....
1. load Candy()  -> into candystore, board, candyland
2. load characters from a file ->
3. choose a character 
4. visiting the candy store to stock up
5. 


*/