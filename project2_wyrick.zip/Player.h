
#ifndef PLAYER_H
#define PLAYER_H


#include <iostream>
#include "Board.h"
using namespace std;




class Player
{

    private:
    const static int _MAX_CANDY_AMOUNT = 9;
    int	_stamina;
    double	_gold;
    string	_name;
    int	_candy_amount;
    Candy _inventory[_MAX_CANDY_AMOUNT];


    public:
    Player(); 
    Player(int stamina, double gold, string name, Candy candy_array[], const int CANDY_ARR_SIZE);
    int getCandyAmount() const;
    void setStamina(int stamina);
    int getStamina() const;
    void setGold(double gold);
    double getGold() const;
    void setName(string name);
    string getName() const;
    void printInventory();
    Candy findCandy(string candy_name) const;
    bool addCandy(Candy candy);
    bool removeCandy(string candy_name);
    Player readPlayer (string file_name, int name);
    void displayStats(Player players[2]);
    

};



#endif