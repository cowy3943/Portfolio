#include <iostream>
#include <vector>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <sstream>
#include "Board.h"
#include "Player.h"

#ifndef TILE_H
#define TILE_H
using namespace std;




class Tile
{

public:

Tile();
void assignHiddenTreasures(Board ) const; // hidden treasures with riddles
int setSpecialTiles(Board, Player);
int setMarshmallowHailstorm(Board, Board) ;
// At least 4 special tiles with a minimum of 25% chance of a tile being a special tile.
int useHiddenTreasures(Player);


private:
string _color;


};


#endif