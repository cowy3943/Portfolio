#include <iostream>
#include <cctype>
#include "CandyLand.h"
#include "Board.h"
#include "Tile.h"
#include "Player.h"
#include "CandyStore.h"
#include <fstream>
#include <sstream>
#include <cstdlib> // rand()
#include <ctime>

using namespace std;




int playRockPaperScissors(Player player) 
{
    string p1choice;

    bool flag = false;
    while(flag == false)
    {
        cout << "Player: Enter r, p, or s" << endl;
        char p1Bet;
        cin >> p1Bet;
        while ((p1Bet!= 'r') && (p1Bet!= 'p') &&(p1Bet!= 's'))
        {
            cout << "Invalid selection!" << endl;
            cin >> p1Bet;
        }
        
        char p2Bet;
        int num3 = (rand() % (3 - 1 + 1)) + 1;
        if (num3 == 1)
        {
            p2Bet = 'r';
        }
        if (num3 == 2)
        {
            p2Bet = 'p';
        }
        if (num3 == 3)
        {
            p2Bet = 's';
        }
       

        if ((p1Bet == 'r' && p2Bet == 's') || (p1Bet == 's' && p2Bet == 'p') ||(p1Bet == 'p' && p2Bet == 'r')) 
        {
            
            cout << "Player has won" << endl;
            flag = true;
            return 5;
        } 
        else if (p1Bet == p2Bet)
        {
            cout << "Tie! Play again" << endl;
            continue;
        } 
        else 
        {
           
            cout << "Player has lost" << endl;
            flag = true;
            return 6;
        }
    }
    return 6;
}




vector<Candy> CandyLand::readCandy(string file_name, vector <Candy> candies)
{
    ifstream file_in;
    file_in.open(file_name);
    string line;
    string name1;
    string	description1;
    string effect_type1;
    string effect_value1;
    string	candy_type1;
    string	price1;
   
    if(file_in.fail())
    {
        cout << "Failed to open file" << endl;
        return candies; // 1 because something went wrong
    }
    string temp; // a temporary string to store the first line
    getline(file_in, temp);

    while(getline(file_in,line))
    {
         if (line == "")
        {
            continue;
        }
        Candy candy;       
        stringstream ss(line); 
        getline(ss,name1, '|'); 
        candy.name = name1;
        getline(ss,description1, '|'); 
        candy.description = description1;
        getline(ss,effect_type1, '|'); 
        candy.effect_type = effect_type1;
        getline(ss,effect_value1, '|');
        double effect_value2 = stod(effect_value1);
        candy.effect_value = effect_value2;
        getline(ss,candy_type1); 
        candy.candy_type = candy_type1;
        getline(ss,price1, '|'); 
        double price2 = stod(price1);
        candy.price = price2;

        candies.push_back(candy);
    }
    file_in.close();
    return candies;
}

void CandyLand::displayCandy(vector<Candy> candies)
{
for (int i = 0; i < candies.size(); i++) {
cout << "Name: " << candies[i].name << ". Description: " << candies[i].description
   <<". Effect Type: " << candies[i].effect_type << ". Effect Value: "<< candies[i].effect_value
    <<". Type: " << candies[i].candy_type << ". Price: " << candies[i].price <<  endl;
}}

void CandyLand::setupGame()
{
    int num;
    cout << "Welcome to the game of candyland. Please enter the number of participants:" << endl;
    cin >> num;
    cout << "Awesome! Here is a list of characters a player can select from: " << endl;
    cout << "character name|stamina|gold|candies" << endl;
    cout << "1. Toffee_Todd|200|20|Frosty Fizz,Toxic Taffy,Bubblegum Blast,Caramel Comet,Lucky Licorice" << endl;
    cout << "2. JellyBean_Jane|100|50|Breezy Butterscotch,Lucky Licorice,Fearsome Fudge,Crimson Crystal" << endl;
    cout << "3. Super_Sally|50|60|Frosty Fizz,Toxic Taffy,Bubblegum Blast,Caramel Comet,Lucky Licorice" << endl;
    cout << "4. Lucky_Loid|60|50|Breezy Butterscotch,Lucky Licorice,Fearsome Fudge,Crimson Crystal" << endl;
    cout << "Enter 2 numbers" << endl;
    Board p1;
    CandyStore f;
    f.setCandyStore(p1);
    CandyLand c;
    Player p;
    Player k;
    Tile t;
    t.assignHiddenTreasures(p1);
    int name1;
    int name2;
    cin >> name1;
    cin >> name2;
    if (name1 == 1)
    {
        p.readPlayer("characters.txt", 1);
    }
    if (name1 == 2)
    {
        p.readPlayer("characters.txt", 2);
    }
    if (name1 == 3)
    {
        p.readPlayer("characters.txt", 3);
    }
    if (name1 == 4)
    {
        p.readPlayer("characters.txt", 4);
    }
    if (name2 == 1)
    {
        k.readPlayer("characters.txt", 1);
    }
    if (name2 == 2)
    {
        k.readPlayer("characters.txt", 2);
    }
    if (name2 == 3)
    {
        k.readPlayer("characters.txt", 3);
    }
    if (name2 == 4)
    {
        k.readPlayer("characters.txt", 4);
    }
    char choice1;
    char choice2;
    cout << "Player 1, would you like to visit the candy Store? (y/n)" << endl;
    cin >> choice1;
    string cfirst;
    string csecond;
    if(choice1 == 'y')
    {
        cout << "Welcome to the candy store. What candy would you like to add?" << endl;
        cout << "Name|Description|Effect type|Effect value|Candy type|Price" << endl;
        cout << "Frosty Fizz|Boosts player's stamina by 10 units|stamina|10|magical|10" << endl;
        cout << "Lucky Licorice|Decreases opponents stamina by 10 units (mild)|stamina|-10|poison|15" << endl;
        cout << "Ruby Rapture|Forms a gummy barrier on a chosen tile and opponent loses 2 turns|turns|-2|gummy|20" << endl;
        getline(cin,cfirst);
        cout << cfirst << " added to inventory" << endl;
    }

    cout << "Player 2, would you like to visit the candy store? (y/n)" << endl;
    cin >> choice2;
    if(choice2 == 'y')
    {
        cout << "Welcome to the candy store. What candy would you like to add?" << endl;
        cout << "Name|Description|Effect type|Effect value|Candy type|Price" << endl;
        cout << "Frosty Fizz|Boosts player's stamina by 10 units|stamina|10|magical|10" << endl;
        cout << "Lucky Licorice|Decreases opponents stamina by 10 units (mild)|stamina|-10|poison|15" << endl;
        cout << "Ruby Rapture|Forms a gummy barrier on a chosen tile and opponent loses 2 turns|turns|-2|gummy|20" << endl;
        getline(cin,csecond);
        cout << csecond << " added to inventory" << endl;
    }

    c.displayMainMenu(p,k);
    p1.setPlayerPosition(82);
     p1.displayBoard();
     cout << "Congratulations! Player 1 progresses to the Castle." << endl;

    
}



Card CandyLand::drawCard ()
{

    Card c;
    int number10 = (rand() % (100 - 1 + 1)) + 1;
    if (number10 >=1 && number10 <= 33)
    {
        c.color = "Bubblegum Blue";
    }
    if (number10 >33 && number10 <= 66)
    {
        c.color = "Cotton Candy Magenta";
    }
    if (number10 > 66 && number10 <= 100)
    {
        c.color = "Minty Green";
    }
    int number11 = (rand() % (100 - 1 + 1)) + 1;
    if (number11 >=1 && number11 <= 70)
    {
        c.type = "single";
    }
    if (number11 >70  && number11 <= 100)
    {
        c.type = "double";
    }

    //c.color = color;
    //c.type = type;
    
    // 33% chance for each color
    // 70% chance for single
    // 30% chance for double
    cout << "You have chosen a" << c.color << " " << c.type << " card" << endl;
   return c;
}

bool CandyLand::samePosition(Board p, Board h, Player a, Player b)
{
if(p.getPlayerPosition() == h.getPlayerPosition())
{
    int num5 = (rand() % (30 - 5 + 1)) + 5;
    a.setGold(a.getGold() + num5);
    b.setGold(b.getGold() - num5);
    h.setPlayerPosition(h.getPlayerPosition() - 1);
// The first player to land on the tile can steal a random amount (5-30 coins) of the other player's gold stock
//The player who reaches the tile first will be moved back by one tile, while the one who arrives later will remain on the tile.
   return true;}
else
{
    return false;
}
} 


int CandyLand::ifCalamities(Player p)
{
// 40% chance of calamities
int number12 = (rand() % (100 - 1 + 1)) + 1;
if (number12 >= 1 && number12 < 60)
{
    //1 means no calamities
    return 1;
}
else
{
    int number13 = (rand() % (100 - 1 + 1)) + 1;
    if (number13 >= 1 && number13 < 30)
    {
        // lose 1-10 gold coins = 2
        int num9 = (rand() % (10 - 1 + 1)) + 1;
        p.setGold(p.getGold() - num9);
        cout << "Oh no! Candy Bandits have swiped your gold coins!" << endl;
        return 1;
    }
    if (number13 >= 30 && number13 < 65)
    {
        cout << "Oh dear! You got lost in the lollipop labyrinth!" << endl;
        // lose turn  if returned 3
        cout << "Would you like to play rock paper scissors to get your turn back? type y for yes or n for no" << endl;
        char letter;
        cin >> letter;
        if (letter == 'n')
        {
            return 3;
        }
        if (letter == 'y')
        {
            if(playRockPaperScissors(p) == 5)
            {
                cout << "Congrats! You get your turn back" << endl;
                return 1;
            }
            else
            {
                return 3;
            }
        }
        //or Play RPC to get turn back
        // if RPC returns 5, player wins
        // if RPC returns 6, player loses
    }
    if (number13 >= 65 && number13 < 80)
    {
        cout << "Watch out! A candy avalanche has struck!" << endl;
        int num13 = (rand() % (10 - 5 + 1)) + 5;
        p.setStamina(p.getStamina() - num13);
        // lose 5 to 10 units of stamina
        // lose turn
        cout << "Would you like to play rock paper scissors to get your turn back? type y for yes or n for no" << endl;
        char letter;
        cin >> letter;
        if (letter == 'n')
        {
            return 3;
        }
        if (letter == 'y')
        {
            if(playRockPaperScissors(p) == 5)
            {
                cout << "Congrats! You get your turn back" << endl;
                return 1;
            }
            else
            {
                return 3;
            }
            
        }
        // play RPC to get stamina back
        // if RPC returns 5, player wins
        // if RPC returns 6, player loses
    }
    if (number13 >= 80 && number13 <=100)
    {
        cout << "Oops! You are stuck in a sticky taffy trap!" << endl;
        return 3;
    }
    else {return 1;}
}
return 1;
} 


void CandyLand::displayMainMenu(Player p, Player h)
{
int option = 0;
int num = 0;

while ((option != 1) && (option != 2) && (option != 3))
{
if (num % 2)
{
cout << "It's Player 1's turn" << endl;
cout << "Please select a menu option:" << endl;
cout << "1. Draw a card" << endl;
cout << "2. Use candy" << endl;
cout << "3. Show player stats" << endl;

cin >> option;

if (option == 1)
{
    cin.clear();
    cin.ignore();
    cout << "To draw a card press D" << endl;
    char letter;
    cin >> letter;
    if (letter == 'D')
    {
        CandyLand w;
        Card c = w.drawCard();
        cout << "You have chosen a " << c.color << " " << c.type << "card" << endl;
        // move to correct tile
        //1. find tile's position based on card stats
        //2. move player position to this tile
    }
    else
    {
        cout << "Wrong letter" << endl;
        continue;
    }
}

if (option == 2)
{
    cout << "Here is a list of your candies:" << endl;
    p.printInventory();
    cout << "Enter a candy you wish to use:" << endl;
    string candy;
    cin >> candy;
    //1. use candy based on properties
    //2, remove candy from inventory
}

if (option == 3)
{
    Player players[2] = {p, h};
    p.displayStats(players);
}
num++;}



else
{
while ((option != 1) && (option != 2) && (option != 3))
{cout << "It's Player 1's turn" << endl;
cout << "Please select a menu option:" << endl;
cout << "1. Draw a card" << endl;
cout << "2. Use candy" << endl;
cout << "3. Show player stats" << endl;

cin >> option;
{
    cout << "To draw a card press D" << endl;
    char letter;
    cin >> letter;
    if (letter == 'D')
    {
        CandyLand w;
        w.drawCard();
        // move to correct tile
        //1. find tile's position based on card stats
        //2. move player position to this tile
    }
    else
    {
        cout << "Wrong letter" << endl;
        continue;
    }
}

if (option == 2)
{
    cout << "Here is a list of your candies:" << endl;
    h.printInventory();
    cout << "Enter a candy you wish to use:" << endl;
    string candy;
    cin >> candy;
    //1. use candy based on properties
    //2, remove candy from inventory
}

if (option == 3)
{
    Player players[2] = {p, h};
    h.displayStats(players);
}
}
num++;
}

return;
}}