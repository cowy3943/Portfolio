#include <iostream>
#include <vector>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <sstream>
#include "CandyStore.h"
#include "Board.h"
#include "Player.h"
#include "CandyLand.h"

using namespace std;



 CandyStore::CandyStore()
 {
    Board c;
    setCandyStore(c);
 }
void CandyStore::setCandyStore(Board c)
{
// sets three candy stores at evenly distributed locations
    int number6 = (rand() % (27 - 1 + 1)) + 1;
    c.addCandyStore(number6);
    int number7 = (rand() % (54 - 28 + 1)) + 28;
    c.addCandyStore(number7);
    int number8 = (rand() % (82 - 55 + 1)) + 55;
    c.addCandyStore(number8);
} 
void CandyStore::displayCandyMenu()
{
    int number9 = (rand() % (100 - 1 + 1)) + 1;
    if (number9 >=1 && number9 <=25)
    {
        // display first 3 candies
    }
    if (number9 >25 && number9 <=50)
    {
        // display second 3 candies
    }
    if (number9 >50 && number9 <=75)
    {
        // display third 3 candies
    }
    if (number9 >75 && number9 <=100)
    {
        // display fourth 3 candies
    }
    //25% chance of each candy occurence; only takes 3

} // displays 3 candies randomly
Player CandyStore::chooseCandy(Player p, Candy c)
{
    cout << "Which candy would you like to add?" << endl;
    string candy_name;
    cin >> candy_name;
    c.name = candy_name;
    p.addCandy(c);
    // player chooses candy and adds to inventory
    return p;
}