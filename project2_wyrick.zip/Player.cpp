#include <iostream>
#include <cctype>
#include "Player.h"
#include "Board.h"
#include "CandyLand.h"
#include <fstream>
#include <sstream>


using namespace std;


Player::Player() 
{
    _stamina = 0;
    _gold = 0.0;
    _name = "";
    _candy_amount = 0;
     _inventory[0] = Candy{"", "", "", "", "", 0.0}; 
     _inventory[1] = Candy{"", "", "", "", "", 0.0}; 
     _inventory[2] = Candy{"", "", "", "", "", 0.0}; 
     _inventory[3] = Candy{"", "", "", "", "", 0.0}; 
     _inventory[4] = Candy{"", "", "", "", "", 0.0};
     _inventory[5] = Candy{"", "", "", "", "", 0.0};
     _inventory[6] = Candy{"", "", "", "", "", 0.0};
     _inventory[7] = Candy{"", "", "", "", "", 0.0};
     _inventory[8] = Candy{"", "", "", "", "", 0.0};

}

Player::Player(int stamina, double gold, string name, Candy candy_array[], const int CANDY_ARR_SIZE) {
    _stamina = stamina;
    _gold = gold;
    _name = name;
    _candy_amount = 0;

    for (int i = 0; i < _MAX_CANDY_AMOUNT && i < CANDY_ARR_SIZE; i++) 
    {
        _inventory[i] = candy_array[i];
        if (!_inventory[i].name.empty()) 
        {
            _candy_amount++;
        }
    }

    for (int i = _candy_amount; i < _MAX_CANDY_AMOUNT; i++) 
    {
        _inventory[i] = Candy{"", "", "", "", "", 0.0}; 
    }
}

int Player::getCandyAmount() const 
{
    return _candy_amount;
}

void Player::setStamina(int stamina) 
{
    _stamina = stamina;
}

int Player::getStamina() const 
{
    return _stamina;
}

void Player::setGold(double gold) 
{
    _gold = gold;
}

double Player::getGold() const 
{
    return _gold;
}

void Player::setName(string name) 
{
    _name = name;
}

string Player::getName() const 
{
    return _name;
}

void Player::printInventory()  
{

    for (int i = 0; i < 3; i++) 
    {
        for (int j = 0; j < 3; j++) 
        {
            int index = i * 3 + j;
            if(_inventory[index].name == "")
            {
                cout << "|[" << "Empty" << "]";
                continue;
            }
            cout << "|[" << _inventory[index].name << "]";
        }
        cout << "|" << endl;
    }
}


Candy Player::findCandy(string candy_name) const 
{
    //  int length = candy_name.length();
    // for (int i = 0; i < length; i++)
    // {
    //     candy_name[i] = tolower(candy_name[i]);
    // }

    for (int i = 0; i < _MAX_CANDY_AMOUNT; i++) 
    {
        if ((_inventory[i].name) == (candy_name)) 
        {
            return _inventory[i];
        }
    }
    return Candy{"", "", "", "","",0.0}; 
}

bool Player::addCandy(Candy candy) 
{
    if (_candy_amount < _MAX_CANDY_AMOUNT) 
    {
        for (int i = 0; i < _MAX_CANDY_AMOUNT; i++) 
        {
            if (_inventory[i].name.empty()) 
            {
                _inventory[i] = candy;
                _candy_amount++;
                return true;
            }
        }
    }
    return false; 
}

bool Player::removeCandy(string candy_name) 
{
    // int length = candy_name.length();
    // for (int i = 0; i < length; i++)
    // {
    //     candy_name[i] = tolower(candy_name[i]);
    // }
    
    for (int i = _MAX_CANDY_AMOUNT - 1; i >= 0; i--) 
    {
    
        if ((_inventory[i].name) == (candy_name)) 
        {
            _inventory[i] = Candy{"", "", "", "", "", 0.0};
            for (int j = i; j < 3 ; j++)
            {
                _inventory[j] = _inventory[j+1];
                _inventory[_MAX_CANDY_AMOUNT-1] = Candy{"", "", "", "", "", 0.0};
            }
            
            _candy_amount--;
            return true;
        }
    }
    return false; 
}

Player Player::readPlayer(string file_name, int num)
{
    Player p;
    ifstream file_in;
    file_in.open(file_name);
    string line;
    string name1;
    string	stamina1;
    string gold1;
    string candy1;
    string	candy2;
    string	candy3;
    string candy4;
   
    if(file_in.fail())
    {
        cout << "Failed to open file" << endl;
        return p; // 1 because something went wrong
    }
    string temp; // a temporary string to store the first line
    getline(file_in, temp);
if (num == 1)
{
    getline(file_in,line);
    
    
        Candy candy_1;    
        Candy candy_2; 
        Candy candy_3; 
        Candy candy_4;    
        stringstream ss(line); 
        getline(ss,name1, '|'); 
        p.setName(name1);
        getline(ss,stamina1, '|'); 
        double stamina2 = stod(stamina1);
        p.setStamina(stamina2);
        getline(ss,gold1, '|'); 
        double gold2 = stod(gold1);
        p.setGold(gold2);
        getline(ss,candy1, ',');
        candy_1.name = candy1;
        p.addCandy(candy_1);
        getline(ss,candy2, ',');
        candy_2.name = candy2;
        p.addCandy(candy_2);
        getline(ss,candy3, ',');
        candy_3.name = candy3;
        p.addCandy(candy_3);
        getline(ss,candy4, ',');
        candy_4.name = candy4;
        p.addCandy(candy_4);
    
    file_in.close();
    return p;}

    else if (num == 2)
{
    string temp1;
    getline(file_in, temp1);
    getline(file_in,line);
    
        Candy candy_1;    
        Candy candy_2; 
        Candy candy_3; 
        Candy candy_4;    
        stringstream ss(line); 
        getline(ss,name1, '|'); 
        p.setName(name1);
        getline(ss,stamina1, '|'); 
        double stamina2 = stod(stamina1);
        p.setStamina(stamina2);
        getline(ss,gold1, '|'); 
        double gold2 = stod(gold1);
        p.setGold(gold2);
        getline(ss,candy1, ',');
        candy_1.name = candy1;
        p.addCandy(candy_1);
        getline(ss,candy2, ',');
        candy_2.name = candy2;
        p.addCandy(candy_2);
        getline(ss,candy3, ',');
        candy_3.name = candy3;
        p.addCandy(candy_3);
        getline(ss,candy4, ',');
        candy_4.name = candy4;
        p.addCandy(candy_4);
    
    file_in.close();
    return p;}
    else if (num == 3)
{

    string temp2;
    string temp3;
    getline(file_in, temp2);
    getline(file_in, temp3);
    getline(file_in,line);
    
    
        Candy candy_1;    
        Candy candy_2; 
        Candy candy_3; 
        Candy candy_4;    
        stringstream ss(line); 
        getline(ss,name1, '|'); 
        p.setName(name1);
        getline(ss,stamina1, '|'); 
        double stamina2 = stod(stamina1);
        p.setStamina(stamina2);
        getline(ss,gold1, '|'); 
        double gold2 = stod(gold1);
        p.setGold(gold2);
        getline(ss,candy1, ',');
        candy_1.name = candy1;
        p.addCandy(candy_1);
        getline(ss,candy2, ',');
        candy_2.name = candy2;
        p.addCandy(candy_2);
        getline(ss,candy3, ',');
        candy_3.name = candy3;
        p.addCandy(candy_3);
        getline(ss,candy4, ',');
        candy_4.name = candy4;
        p.addCandy(candy_4);
    
    file_in.close();
    return p;}
    else
{

    string temp4;
    string temp5;
    getline(file_in, temp4);
    getline(file_in, temp5);
    getline(file_in,line);
    
    
        Candy candy_1;    
        Candy candy_2; 
        Candy candy_3; 
        Candy candy_4;    
        stringstream ss(line); 
        getline(ss,name1, '|'); 
        p.setName(name1);
        getline(ss,stamina1, '|'); 
        double stamina2 = stod(stamina1);
        p.setStamina(stamina2);
        getline(ss,gold1, '|'); 
        double gold2 = stod(gold1);
        p.setGold(gold2);
        getline(ss,candy1, ',');
        candy_1.name = candy1;
        p.addCandy(candy_1);
        getline(ss,candy2, ',');
        candy_2.name = candy2;
        p.addCandy(candy_2);
        getline(ss,candy3, ',');
        candy_3.name = candy3;
        p.addCandy(candy_3);
        getline(ss,candy4, ',');
        candy_4.name = candy4;
        p.addCandy(candy_4);
    
    file_in.close();
    return p;}
    }


void Player::displayStats(Player players[2])
{
Player p = players[0];
Player h = players[1];
ofstream fout;
fout.open("results.txt");
fout << "Player1 stats:" << endl;
fout << "Stamina: " << p.getStamina() << endl;
fout << "Gold: " << fixed << setprecision(2) << p.getGold() << endl;
fout << "Inventory:" << endl;
for (int i =0; i < 9; i++)
{
    fout << _inventory[i].name << ", ";
}
fout.close();

cout << "Player1 stats:" << endl;
cout << "Stamina: " << p.getStamina() << endl;
cout << "Gold: " << fixed << setprecision(2) << p.getGold() << endl;
cout << "Inventory:" << endl;
p.printInventory();


fout.open("results.txt");
fout << "Player2 stats:" << endl;
fout << "Stamina: " << h.getStamina() << endl;
fout << "Gold: " << fixed << setprecision(2) << h.getGold() << endl;
fout << "Inventory:" << endl;
for (int i =0; i < 9; i++)
{
    fout << _inventory[i].name << ", ";
}
fout.close();

cout << "Player2 stats:" << endl;
cout << "Stamina: " << h.getStamina() << endl;
cout << "Gold: " << fixed << setprecision(2) << h.getGold() << endl;
cout << "Inventory:" << endl;
h.printInventory();

};
