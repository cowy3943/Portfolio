#include <iostream>
#include <vector>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <sstream>
#include "Board.h"
#include "Player.h"

#ifndef CANDYSTORE_H
#define CANDYSTORE_H
using namespace std;




class CandyStore
{

    public:
    CandyStore(); //sets default posisitions
    void setCandyStore(Board); // sets three candy stores at locations
    void displayCandyMenu(); // displays 3 candies randomly
    Player chooseCandy(Player, Candy); // if player array of 9 is full, display substitution menu

    private:
    vector <Candy> candies;

};



#endif